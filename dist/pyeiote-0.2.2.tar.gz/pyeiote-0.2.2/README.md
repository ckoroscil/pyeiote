# pyeiote

A simple enterprise IoT traffic emulator.


# Installation

```bash
python -m pip install git+https://github.com/ckoroscil/pyeiote.git
```

# Usage

```bash
python3 -m pyeiote --debug -i eth0
```

# Build

```bash
python3 -m pip install --upgrade build
python3 -m build
```