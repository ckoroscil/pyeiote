# pyeiote

A simple enterprise IoT traffic emulator.
